package clases;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ff_ma
 */
public class Constantes {

    /**
     * Variables
     */
    public static String BBDD  = "juegoBBDD";
    public static String usuario  = "marina";
    public static String password  = "Chubaca2019";
}
