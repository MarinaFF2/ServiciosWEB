package clases;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ff_ma
 */
public class Usuario {
    private String correo;
    private int rol;
    private String pwd;
    private String nombre;
    private String apellido;

    public Usuario(String correo, String pwd, String nombre, String apellido,int rol) {
        this.correo = correo;
        this.rol = rol;
        this.pwd = pwd;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    @Override
    public String toString() {
        return "Usuario{" + "correo=" + correo + ", rol=" + rol + ", pwd=" + pwd + ", nombre=" + nombre + ", apellido=" + apellido + '}';
    }

    
    
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getRol() {
        return rol;
    }

    public void setRol(int rol) {
        this.rol = rol;
    }

    public String getClave() {
        return pwd;
    }

    public void setClave(String pwd) {
        this.pwd = pwd;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    String getTexto() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
