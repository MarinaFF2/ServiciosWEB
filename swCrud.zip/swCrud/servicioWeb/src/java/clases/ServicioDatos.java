package clases;

import com.google.gson.Gson;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;

/*
 * En este ejemplo se servirán (en formato JSON) los datos que se almacenan en la lista List<Datos>. El obtener los datos de una BD
 * es tan sencillo como acceder a los datos como hemos hecho siempre y convertirlos en JSON usando Gson.
 */
/**
 *
 * @author faranzabe
 */
@Path("ServicioDatos")
public class ServicioDatos {

//    Ejemplo de consumo: http://localhost:9090/servicioWeb/app/ServicioDatos/index?usuario=".$correo."&pwd=".$pass -- Busca el elemento 3.
    @GET
    @Path("/index")
    @Produces({MediaType.APPLICATION_JSON})
    public String getData1(@QueryParam("usuario") String id, @QueryParam("pwd") String pwd) {
        ConexionEstatica.nueva();
        Usuario result = ConexionEstatica.existeUsuario(id, pwd);
        ConexionEstatica.cerrarBD();
        Gson gson = new Gson();
        String jsonObj = "";

        if (result != null) {
            jsonObj = gson.toJson(result);
        }
        if (jsonObj.isEmpty()) {
            jsonObj = gson.toJson("No encontrado");
        }
        return jsonObj;
    }

    @GET
    @Path("/registrarse")
    @Produces({MediaType.APPLICATION_JSON})
    public void getData1(@QueryParam("usuario") String id, @QueryParam("pwd") String pwd, @QueryParam("nombre") String nombre, @QueryParam("apellido") String apellido, @QueryParam("rol") int rol) {
        ConexionEstatica.nueva();
        ConexionEstatica.Insertar_Usuario(id, pwd, nombre, apellido, rol);
        ConexionEstatica.cerrarBD();
    }

    @GET
    @Path("/listaUsuarios")
    @Produces({MediaType.APPLICATION_JSON})
    public String getData2() {
        ConexionEstatica.nueva();
        List<Usuario> result = (List<Usuario>) ConexionEstatica.obtenerUsuarios();
        ConexionEstatica.cerrarBD();
        Gson gson = new Gson();
        String jsonObj = gson.toJson(result);
        if (jsonObj.isEmpty()) {
            jsonObj = gson.toJson("No encontrado");
        }
        return jsonObj;
    }

    @GET
    @Path("/editarUsuario")
    @Produces({MediaType.APPLICATION_JSON})
    public String getData3(@QueryParam("usuario") String id, @QueryParam("nombre") String nombre, @QueryParam("apellido") String apellido, @QueryParam("rol") int rol) {
        try {
            ConexionEstatica.nueva();
            ConexionEstatica.ModificarUsuarios(id, nombre, apellido);
            ConexionEstatica.cerrarBD();
        } catch (SQLException ex) {
            Logger.getLogger(ServicioDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            ConexionEstatica.nueva();
            ConexionEstatica.ModificarRol(id, rol);
            ConexionEstatica.cerrarBD();
        } catch (SQLException ex) {
            Logger.getLogger(ServicioDatos.class.getName()).log(Level.SEVERE, null, ex);
        }
        String jsonObj = getData2();
        return jsonObj;
    }

    @GET
    @Path("/eliminarUsuario")
    @Produces({MediaType.APPLICATION_JSON})
    public String getData4(@QueryParam("usuario") String id) {
        try {
            ConexionEstatica.nueva();
            ConexionEstatica.BorrarUsuario(id);
            ConexionEstatica.cerrarBD();
        } catch (SQLException ex) {
            Logger.getLogger(ServicioDatos.class.getName()).log(Level.SEVERE, null, ex);
        }

        String jsonObj = getData2();
        return jsonObj;
    }
}
