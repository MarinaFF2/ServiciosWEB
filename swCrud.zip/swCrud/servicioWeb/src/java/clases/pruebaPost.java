package clases;


import com.google.gson.Gson;
import java.io.IOException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author faranzabe
 */
@Path("/pruebaPost/")
public class pruebaPost {

    /*
    A continuación dos proyectos servicios web diferentes. Hacen lo mismo pero al cliente le devuelven diferente tipo de respuesta.
    Aceptan un String en el que se le envían datos en formato JSON. Una vez convertidos en objetos su tratamiento es el que queramos: insertar
    en una lista, en una BD... lo que queramos.
    Después cada método devuelve cosas diferentes al cliente:
    post --> un texto usando Response.
    post2 --> un string estándar de Java.
    post3 --> un json.
    post4 --> colección de json.
    */
    
    //Este servicio se consume con el proyecto ClientePost.
    @POST
    @Path("/registrarse")
    @Consumes("application/json")
    //@Consumes(MediaType.APPLICATION_JSON)
    //@Consumes("*/*")
    public Response crearDato(String stream) throws IOException {
        Gson gson = new Gson();
        Usuario dato = gson.fromJson(stream, Usuario.class);
        String result = "Elemento creado en el servidor: " + dato;
        return Response.ok(result).build();

    }
    
     
}
