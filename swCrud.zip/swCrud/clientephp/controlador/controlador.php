<?php

require_once '../clase/Usuario.php';

session_start();
//para recoger las sesiones inicializadas
if (isset($_SESSION['usu'])) {
    $usu = $_SESSION['usu'];
    $cor = $_SESSION['cor'];
}

/**
 * Ventana registrarse
 */
if (isset($_REQUEST['registrar'])) {
    $correo = $_REQUEST['correo'];
    $pass = $_REQUEST['clave'];
    $repass = $_REQUEST['reclave'];
    if ($pass == $repass) {
        if ($u == null) { //solo funciona si es diferente de null, porque no detecta que esta vacio
            $nom = $_REQUEST['nombre'];
            $ape = $_REQUEST['apellido'];
            $ch = curl_init("http://localhost:9090/WebServices/swCrud/servicioWeb/app/pruebaPost/registrarse?usuario=" . $correo . "&pwd=" . $pass . "&nombre=" . $nombre . "&apellido=" . $apellido . "&rol=" . $rol); //Servicio creado en JSP.

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            $response = curl_exec($ch);
            curl_close($ch);
            if (!$response) {
                return false;
            } else {
                $u = json_decode($response, true);
                header('Location: ../index.php');
            }
        }
    } else {
        header('Location: ../vista/registrarse.php');
    }
}
if (isset($_REQUEST['volver'])) {
    header("Location: ../index.php");
}
/**
 * Ventana inicar sesion / index
 */
if (isset($_REQUEST['aceptarIndex'])) {
    $correo = $_REQUEST['usuario'];
    $pass = $_REQUEST['pwd'];
    $ch = curl_init("http://localhost:9090/servicioWeb/app/ServicioDatos/index?usuario=" . $correo . "&pwd=" . $pass); //Servicio creado en JSP.

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    $response = curl_exec($ch);
    curl_close($ch);
    if (!$response) {
        return false;
    } else {
        $usu = json_decode($response, true);
        if ($usu != null) {
            $_SESSION['usu'] = $usu;
            $_SESSION['cor'] = $correo;
            $rol = $usu['rol'];
            if ($rol == 0) { //si eres jugador
                header('Location: ../vista/juego.php');
            }
            if ($rol == 1) { //si eres administrador
                $ch = curl_init("http://localhost:9090/servicioWeb/app/ServicioDatos/listaUsuarios"); //Servicio creado en JSP.

                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
                $response1 = curl_exec($ch);
                curl_close($ch);
                if (!$response1) {
                    return false;
                } else {
                    $v = json_decode($response1, true);
                    $_SESSION['listU'] = $v;
                    header('Location: ../vista/crudUsuario.php');
                }
            }
        } else {
//            header('Location: ../index.php');
        }
    }
}

//estas en el crud de usuario (siendo admin)
if (isset($_REQUEST['botUsuario'])) {

    //cuando editas a un usuario
    if ($_REQUEST['botUsuario'] == 'Editar') {
        $correo = $_REQUEST['correo'];
        $nombre = $_REQUEST['nombre'];
        $apellido = $_REQUEST['apellido'];
        $rol = $_REQUEST['rol'];
        $ch = curl_init("http://localhost:9090/servicioWeb/app/ServicioDatos/editarUsuario?usuario=" . $correo . "&nombre=" . $nombre . "&apellido=" . $apellido . "&rol=" . $rol); //Servicio creado en JSP.
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        $response1 = curl_exec($ch);
        curl_close($ch);
        if (!$response1) {
            return false;
        } else {
            $v = json_decode($response1, true);
            $_SESSION['listU'] = $v;
            header('Location: ../vista/crudUsuario.php');
        }

        //Cuando eliminas a un usuario
        if ($_REQUEST['botUsuario'] == 'X') {
            $correo = $_REQUEST['correo'];
            $ch = curl_init("http://localhost:9090/servicioWeb/app/ServicioDatos/editarUsuario?usuario=" . $correo); //Servicio creado en JSP.
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            $response1 = curl_exec($ch);
            curl_close($ch);
            if (!$response1) {
                return false;
            } else {
                $v = json_decode($response1, true);
                $_SESSION['listU'] = $v;
                header('Location: ../vista/crudUsuario.php');
            }
        }
    }
}        