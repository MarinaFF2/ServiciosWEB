<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Juego</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../files/bootstrap-4.3.1-dist/css/bootstrap.min.css">
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="../files/jquery-3.3.1.slim.min.js"></script>
        <script src="../files/popper.min.js"></script>
        <script src="../files/bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
        <!--        <link rel="stylesheet" type="text/css" href="../css/css_.css" media="screen" />-->
        <script src="../jquery-3.4.1.min.js"></script>

    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col">                    
                    <div class="text-right ">
                        <p>Hola Fulanit@</p>
                    </div>                             
                </div>
            </div>
        </div>
    </body>
</html>