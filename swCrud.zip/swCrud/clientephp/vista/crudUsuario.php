<?php
require_once '../clase/Usuario.php';
session_start();
$v = $_SESSION['listU'];
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Crud usuarios</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    </head>
    <body>
        <table>
            <caption>LISTA USUARIOS</caption>
            <thead>
                <tr>
                    <th>CORREO</th>
                    <th>NOMBRE</th>
                    <th>APELLIDO</th>
                    <th>ROL</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($v as $key) {
                    ?>
                <form action="../controlador/controlador.php" method="get">
                    <tr>
                        <td>
                            <input type="text" name="correo" value="<?php echo $key['correo']; ?>" readonly/>
                        </td> 
                        <td>
                            <input type="text"  name="nombre"  value="<?php echo $key['nombre']; ?>"/>
                        </td>   
                        <td>
                            <input type="text"  name="apellido" value="<?php echo $key['apellido']; ?>"/>
                        </td>
                        <td>
                            <input type="number" name="rol" value="<?php echo $key['rol']; ?>"/>
                        </td>
                        <td>
                            <input type="submit" id="eliminar" name="botUsuario" value="X"/>
                        </td>
                        <td>
                            <input type="submit" id="editar" name="botUsuario" value="Editar"/>
                        </td>
                    </tr>
                </form>
                <?php
            }
            ?>
        </tbody>
    </table>
</body>
</html>